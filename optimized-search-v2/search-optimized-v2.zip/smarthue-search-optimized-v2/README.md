# SmartHue — Searching optimized v2

This separate candidate replaces ONLY 01-tim-den.lottie from the previous optimized package. Other clips, originals and existing public previews are unchanged. Keep all other optimized files from that package.

File size: 1,156,565 → 636,981 bytes (44.9% smaller than optimized v1, 77.7% smaller than original 2,862,293-byte delivery). Preserve 393×326, 60 fps, 240 frames / 4s and speed 1. Linear tracks were reduced using bounded interpolation error; first and visible final frame 239 are explicitly anchored. Embedded image assets are unchanged. Do not treat this as a lossless export.

Validation: 31 rendered timestamps compared against optimized v1. Mean absolute RGB error: 0.009309 on a 0–255 scale; worst frame-average error: 0.027838. First rendered frame matches exactly; final-frame difference is confined to one antialiased pixel, maximum channel difference 2/255. Full-flow completion sequence 1 → 2 → 5 → 3 → 4 → 1 passed with no browser errors. Sampled rendering does not certify every intermediate frame or every native player; test the app's actual renderer.

Preview: https://nguyenphuadta.github.io/smarthue-animation-demo/optimized-search-v2/?rev=optimized-search-v2
Previous optimized reference: https://nguyenphuadta.github.io/smarthue-animation-demo/optimized/?rev=optimized-v1

Integration: replace only file 01 after accepting this candidate. Finish the entire current animation before changing states. Use completion callbacks, autoplay=false/loop=false and a pending state target; repeat the whole waiting clip while no target is pending. Keep routing 1 → 2 → 5 → 3 → 4, error branches 1 → 7 and 3 → 8; 06 remains retired. Preload the next player and keep the final frame visible until it is ready.

# SmartHue — bàn giao dev · 15/10/2026 · v19

Đọc toàn bộ README trước khi tích hợp. Bắt buộc xem preview full app để đối chiếu bố cục, thứ tự và nhịp chuyển, không chỉ mở từng file riêng lẻ.

- Preview online: https://nguyenphuadta.github.io/smarthue-animation-demo/?mode=sequence&rev=near-15cm-v19
- Preview HTML trong gói: full-app-preview/index.html. Mở bằng trình duyệt; nếu môi trường chặn file://, phục vụ thư mục này bằng một static HTTP server. Dữ liệu đi kèm, không cần tải animation từ CDN.
- Canvas animation: 393×326; trong màn app tham chiếu 393×852. 60 FPS, speed=1. Dùng LottieFiles dotlottie-ios theo package của app. Chưa đo hiệu năng bản này trên thiết bị iOS thật; preview web không xác nhận FPS iOS.

## Các file và thời lượng

| File | Vai trò | Thời lượng |
|---|---|---:|
| 00-before-scan.lottie | Hướng dẫn tắt đèn → chờ → bật lại | 8s |
| 01-tim-den.lottie | Tìm đèn; dùng cho các lượt lặp tiếp theo | 4s |
| 02-tim-thay.lottie | Tìm thấy | 4,6s |
| 05-tim-thay-den-ket-noi.lottie | Nối Tìm thấy → Đang kết nối | 2,8s |
| 03-dang-ket-noi.lottie | Đang kết nối | 2s |
| 04-thanh-cong.lottie | Thành công | 7,5s |
| 07-no-light-found.lottie | Không tìm thấy đèn | 4,2s |
| 08-connection-timeout.lottie | Kết nối quá thời gian | 4s |

Không dùng file 06: đoạn nối Đang kết nối → Thành công đã được bỏ. Phát 04 trực tiếp sau 03 hoàn tất.

## Rule chuyển state — bắt buộc

**Ngoại lệ duy nhất: animation 0.** Khi user bấm Scan Now, agent phải xử lý chuyển cảnh trong code: preload animation 1; cho riêng vùng animation 0 fade out trong 280ms (giao diện app không fade); hết fade thì dừng animation 0 và phát thẳng `01-tim-den.lottie` từ frame 0, khôi phục opacity vùng animation về 1. Không dùng clip entry riêng và không thêm fade in lần nữa. Nếu animation 1 chưa preload xong, giữ animation 0 trên màn hình đến khi sẵn sàng rồi mới fade out.

Ngoại lệ này cho phép user rời animation 0 ngay khi bấm Scan Now. **Tất cả clip còn lại phải phát HẾT clip hiện tại trước khi đổi sang clip kế tiếp.** Nhận sự kiện thiết bị giữa chừng thì lưu pending state; chỉ tiêu thụ pending ở completion callback. Không dùng thời gian ước lượng để cắt clip, không tua/nhảy giữa các đoạn khi state thay đổi. Preload clip kế tiếp để tránh giật/chờ tải ở ranh giới.

- Trước Scan: phát 00 từ frame 0. Sau lượt đầu, lặp [20,480) để bỏ fade in ban đầu; không tự chuyển sang tìm đèn. API dùng frame cuối inclusive thì kết thúc ở 479.
- Sau Scan: phát 01 từ frame 0. Nếu chưa có kết quả khi clip hoàn tất, lặp toàn bộ [0,240).
- Đang tìm + có kết quả: chờ 01 hoàn tất → 02. Không có kết quả: chờ 01 hoàn tất → 07.
- 02: khi cần kết nối, chờ 02 hoàn tất → 05 → 03. 05 phải chạy hết. Nếu state đến sớm trong 02, lưu pending.
- 03: chưa có kết quả thì lặp toàn bộ [0,120). Có kết quả thì chờ hoàn tất → 04 thành công hoặc → 08 timeout. Frame đầu 08 kế thừa điểm kết của 03.
- 04: trạng thái thành công cuối cùng. Chờ hết clip rồi đi tiếp theo UX của app; không tự quay về 00/01 trong production.
- 07/08: hiển thị nhánh lỗi và nút thử lại theo UX của app; tiếp tục giữ rule completion nếu cần đổi clip. File lỗi có thể lặp toàn bộ khi chờ thao tác.

Preview “full flow” là demo 00 (bấm Scan, fade out) → 01 → 02 → 05 → 03 → 04 rồi lặp 01 → 02 → 05 → 03 → 04. Production phải dùng sự kiện BLE thật, không sao chép cơ chế tự tiến của demo.

## Những thay đổi cần cập nhật

- Animation 0 mới dài 8s. Fade in đầu → nghỉ khoảng 0,92s → công tắc và đèn cùng tắt. Sóng trong cụm 10s fill trong 1,5s; đây là minh họa, KHÔNG phải đếm đủ 10 giây thật. Các cụm đổi bằng fade và dịch nhẹ 3px, không spring. Cuối clip trở về Turn It Off để khớp lượt lặp. Không có fade out toàn cảnh được bake ở cuối; fade out chỉ chạy khi app nhận thao tác Scan Now.
- Bóng chữ 0 dùng đúng PNG của bộ cũ, vị trí designer đã chốt: X=-149, Y=150,2, scale=116%, opacity=100%. Cả Turn It Off, Turn It On và Please Wait dùng chung bóng. Please Wait đã căn cùng chân chữ. Sàn có mép trên/dưới mềm và trong suốt dần, nằm trong Lottie.
- Khoảng cách gần ở animation 1 là **15cm**, xa nhất vẫn **2m**. Số chạy liên tục theo chuyển động, về gần dừng ở 15cm. Giữ dấu check và bố cục đã chốt. Các frame kế thừa ở 02/05/07 cũng đồng bộ 15cm để không nhảy về 30cm khi nối.
- Đây là bộ giữ nguyên dữ liệu chuyển động của bản gốc được duyệt. Không dùng bộ tối ưu v1–v4, không giảm keyframe chuyển động, không đổi FPS xuống 30. Thay đổi số khoảng cách chỉ cập nhật các layer glyph/visibility liên quan. Không có animation entry riêng; app tự fade out animation 0 khi Scan Now rồi chạy thẳng animation 1.
- Bỏ các override căn check/bóng từ bản preview cũ trong app. Vị trí đã được đưa trực tiếp vào file bàn giao. Browser localStorage chỉ phục vụ công cụ căn chỉnh, không phải cấu hình cho production.

## Render và bố cục

Giữ đúng tỉ lệ 393:326, không kéo méo, không tự crop nội dung. Background ngoài vùng sàn là trong suốt; nền app tham chiếu #0C0C0C. Animation nằm dưới các lớp UI. Chữ giao diện và nút Scan Now thuộc app, không nằm trong file animation.

Gói chỉ có .lottie ở thư mục gốc và README; dữ liệu JSON/JS trong full-app-preview chỉ phục vụ HTML demo. Không lấy những tệp demo đó thay cho .lottie khi tích hợp native. PNG đã nhúng trong các file .lottie, không cần thư mục ảnh rời.

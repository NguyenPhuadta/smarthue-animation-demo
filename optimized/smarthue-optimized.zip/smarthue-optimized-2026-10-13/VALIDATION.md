# Optimized candidate validation

Compared all 7 clips with their original full-precision versions using headless Chrome and lottie-web. Five sample frames per clip (start, 25%, midpoint, 75%, final): 35 comparisons total. Average absolute RGB channel difference: 0.028581 on a 0–255 scale; largest frame-average difference: 0.050806. Some antialiased edge pixels differ more; this is numerical quantization, not a pixel-identical export. These sampled checks do not certify every possible intermediate frame or every native player.

Verified metadata for all clips: 60 fps, original frame counts, original durations. Full-flow completion events were 1 → 2 → 5 → 3 → 4 → 1 with no browser errors. No-light-found start/end loop images are identical. Connecting→Success and Connecting→Timeout differ by one color level at one pixel in these captures. Searching→No-light-found has the same one-color-level seam differences as the original captures; optimization did not increase them.

The existing delivery and root public preview were not modified. Test the target app renderer before accepting this candidate.

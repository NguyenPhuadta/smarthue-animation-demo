# SmartHue — Animation handoff for developer agents

## Optimized candidate — 13 October 2026

This is a separate candidate. The existing original delivery and public demo are preserved. Optimization rounds numeric floating-point values to three decimal places and uses ZIP Deflate level 9. It does not remove keyframes, change playback speed, lower the 60 fps metadata, resize images or change routing/durations. Embedded image strings remain unchanged. Numeric rounding is a small lossy change, so approve the visual comparison before replacing the original app assets.

Total seven animation files: 7,220,338 → 3,642,970 bytes (49.5% smaller). This size excludes HTML preview/runtime assets.

| File | Original bytes | Optimized bytes |
|---|---:|---:|
| 01-tim-den.lottie | 2,862,293 | 1,156,565 |
| 02-tim-thay.lottie | 1,598,060 | 831,972 |
| 03-dang-ket-noi.lottie | 109,259 | 105,927 |
| 04-thanh-cong.lottie | 390,516 | 368,762 |
| 05-tim-thay-den-ket-noi.lottie | 853,432 | 491,872 |
| 07-no-light-found.lottie | 1,296,283 | 591,379 |
| 08-connection-timeout.lottie | 110,495 | 96,493 |

Public candidate preview: https://nguyenphuadta.github.io/smarthue-animation-demo/optimized/?rev=optimized-v1
Original reference: https://nguyenphuadta.github.io/smarthue-animation-demo/?rev=timeout-entry-v15
Start the full flow or select any individual clip on the public candidate preview. Its data comes from these optimized files.

Keep the mandatory complete-before-transition rule in the integration instructions below. Keep 06 retired. Do not replace original assets until this candidate is accepted.


## Integration

Before integration, watch the public candidate preview and compare it with the original reference. Read VALIDATION.md for measured differences and test limits.

Canvas: 393×326, 60 fps. App reference frame: 393×852; animation slot X=0, Y=276, width=393, height=326. Place animation beneath app UI. Preserve the transparent soft floor and shadows.

Files/durations: 01 searching 4s; 02 found 4.6s; 03 connecting 2s; 04 success 7.5s; 05 found→connecting bridge 2.8s; 07 no-light-found 4.2s; 08 timeout 4s. Clip 06 is retired and not included.

Successful route: 1 → 2 → 5 → 3 → 4. Error routes: 1 → 7; 3 → 8. Always finish the entire current clip before starting the next. Set autoplay=false and loop=false; store a pending application target, and consume it on the completion callback. Repeat the whole current waiting/error file when no target is pending. Play bridge 05 once. Do not seek to an exit marker or impose a timer. Success enters directly from Connecting; no bridge 06. Timeout's 0.2s entry hold is embedded, so do not add another delay.

Keep playback speed 1 and enable subframe interpolation where supported. Preload the next player and retain the outgoing final frame until the next player is ready. Dispose stale listeners. The app controls scan/timeout thresholds and retry behavior; the preview loops the successful route only for demonstration.

Image assets are embedded and unchanged. No standalone animation JSON is supplied. Extract the package and use its seven dotLottie files only after this candidate is accepted.

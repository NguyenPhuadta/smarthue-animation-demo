# SmartHue — effects only · v21.1 · 393x326 · 22/10/2026

Đọc toàn bộ README trước khi tích hợp. Bắt buộc xem preview hiệu ứng để đối chiếu bố cục, thứ tự và nhịp chuyển, không chỉ mở từng file riêng lẻ.

- Preview online: https://nguyenphuadta.github.io/smarthue-animation-demo/?collection=smarthue&variant=393x326&clip=flow&v=gradient-v21-1-20261022
- Preview HTML trong gói: full-app-preview/index.html. Mở bằng trình duyệt; nếu môi trường chặn file://, phục vụ thư mục này bằng một static HTTP server. Dữ liệu đi kèm, không cần tải animation từ CDN.
- Canvas animation: 393×326; preview chỉ hiển thị hiệu ứng, không có UI điện thoại. 60 FPS, speed=1. Dùng LottieFiles dotlottie-ios theo package của app. Chưa đo hiệu năng bản này trên thiết bị iOS thật; preview web không xác nhận FPS iOS.

## Các file và thời lượng

| File | Vai trò | Thời lượng |
|---|---|---:|
| 00-before-scan.lottie | Hướng dẫn tắt đèn → chờ → bật lại | 8s |
| 01-tim-den.lottie | Tìm đèn; dùng cho các lượt lặp tiếp theo | 4s |
| 02-tim-thay.lottie | Tìm thấy | 4,6s |
| 05-tim-thay-den-ket-noi.lottie | Nối Tìm thấy → Đang kết nối | 2,8s |
| 03-dang-ket-noi.lottie | Đang kết nối | 2s |
| 04-thanh-cong.lottie | Thành công | 7,5s |
| 07-no-light-found.lottie | Không tìm thấy đèn | 4,2s |
| 08-connection-timeout.lottie | Kết nối quá thời gian | 4s |

Không dùng file 06: đoạn nối Đang kết nối → Thành công đã được bỏ. Phát 04 trực tiếp sau 03 hoàn tất.

## Rule chuyển state — bắt buộc

**Ngoại lệ duy nhất: animation 0.** Khi user bấm Scan Now, agent phải xử lý chuyển cảnh trong code: preload animation 1; cho riêng vùng animation 0 fade out trong 280ms (giao diện app không fade); hết fade thì dừng animation 0 và phát thẳng `01-tim-den.lottie` từ frame 0, khôi phục opacity vùng animation về 1. Không dùng clip entry riêng và không thêm fade in lần nữa. Nếu animation 1 chưa preload xong, giữ animation 0 trên màn hình đến khi sẵn sàng rồi mới fade out.

Ngoại lệ này cho phép user rời animation 0 ngay khi bấm Scan Now. **Tất cả clip còn lại phải phát HẾT clip hiện tại trước khi đổi sang clip kế tiếp.** Nhận sự kiện thiết bị giữa chừng thì lưu pending state; chỉ tiêu thụ pending ở completion callback. Không dùng thời gian ước lượng để cắt clip, không tua/nhảy giữa các đoạn khi state thay đổi. Preload clip kế tiếp để tránh giật/chờ tải ở ranh giới.

- Trước Scan: phát 00 từ frame 0. Sau lượt đầu, lặp [20,480) để bỏ fade in ban đầu; không tự chuyển sang tìm đèn. API dùng frame cuối inclusive thì kết thúc ở 479.
- Sau Scan: phát 01 từ frame 0. Nếu chưa có kết quả khi clip hoàn tất, lặp toàn bộ [0,240).
- Đang tìm + có kết quả: chờ 01 hoàn tất → 02. Không có kết quả: chờ 01 hoàn tất → 07.
- 02: khi cần kết nối, chờ 02 hoàn tất → 05 → 03. 05 phải chạy hết. Nếu state đến sớm trong 02, lưu pending.
- 03: chưa có kết quả thì lặp toàn bộ [0,120). Có kết quả thì chờ hoàn tất → 04 thành công hoặc → 08 timeout. Frame đầu 08 kế thừa điểm kết của 03.
- 04: trạng thái thành công cuối cùng. Chờ hết clip rồi đi tiếp theo UX của app; không tự quay về 00/01 trong production.
- 07/08: hiển thị nhánh lỗi và nút thử lại theo UX của app; tiếp tục giữ rule completion nếu cần đổi clip. File lỗi có thể lặp toàn bộ khi chờ thao tác.

Preview “full flow” là demo 00 (bấm Scan, fade out) → 01 → 02 → 05 → 03 → 04 rồi lặp 01 → 02 → 05 → 03 → 04. Production phải dùng sự kiện BLE thật, không sao chép cơ chế tự tiến của demo.

## Những thay đổi cần cập nhật

- Animation 0 mới dài 8s. Fade in đầu → nghỉ khoảng 0,92s → công tắc và đèn cùng tắt. Sóng trong cụm 10s fill trong 1,5s; đây là minh họa, KHÔNG phải đếm đủ 10 giây thật. Các cụm đổi bằng fade và dịch nhẹ 3px, không spring. Cuối clip trở về Turn It Off để khớp lượt lặp. Không có fade out toàn cảnh được bake ở cuối; fade out chỉ chạy khi app nhận thao tác Scan Now.
- Bóng chữ 0 dùng đúng PNG của bộ cũ, vị trí designer đã chốt: X=-149, Y=150,2, scale=116%, opacity=100%. Cả Turn It Off, Turn It On và Please Wait dùng chung bóng. Please Wait đã căn cùng chân chữ. Sàn có mép trên/dưới mềm và trong suốt dần, nằm trong Lottie.
- Khoảng cách gần ở animation 1 là **15cm**, xa nhất vẫn **2m**. Số chạy liên tục theo chuyển động, về gần dừng ở 15cm. Giữ dấu check và bố cục đã chốt. Các frame kế thừa ở 02/05/07 cũng đồng bộ 15cm để không nhảy về 30cm khi nối.
- Đây là bộ giữ nguyên dữ liệu chuyển động của bản gốc được duyệt. Không dùng bộ tối ưu v1–v4, không giảm keyframe chuyển động, không đổi FPS xuống 30. Thay đổi số khoảng cách chỉ cập nhật các layer glyph/visibility liên quan. Không có animation entry riêng; app tự fade out animation 0 khi Scan Now rồi chạy thẳng animation 1.
- Bỏ các override căn check/bóng từ bản preview cũ trong app. Vị trí đã được đưa trực tiếp vào file bàn giao. Browser localStorage chỉ phục vụ công cụ căn chỉnh, không phải cấu hình cho production.

## Render và bố cục

Giữ đúng tỉ lệ 393:326, không kéo méo, không tự crop nội dung. Background ngoài vùng sàn là trong suốt; nền app tham chiếu #0C0C0C. Animation nằm dưới các lớp UI. Chữ giao diện và nút Scan Now thuộc app, không nằm trong file animation.

Gói chỉ có .lottie ở thư mục gốc và README; dữ liệu JSON/JS trong full-app-preview chỉ phục vụ HTML demo. Không lấy những tệp demo đó thay cho .lottie khi tích hợp native. PNG đã nhúng trong các file .lottie, không cần thư mục ảnh rời.

## v20 — hiệu ứng riêng, mép sàn #0C0C0C

- Bỏ khung điện thoại, status bar, headline, lamp-name, hướng dẫn app, home indicator và top glow của UI. Các chi tiết nằm trong animation (người/đèn/chữ/khoảng cách/icon) vẫn giữ nguyên.
- Hai mép mờ trên/dưới sàn đổi sang #0C0C0C. Ảnh alpha sàn gốc được giữ lossless làm matte; chỉ thêm phần màu gradient trong precomposition sàn. Giữa sàn giữ trắng như gốc. Transforms, opacity, keyframes, easing, frame rate và thời lượng của mọi layer hiện có giữ nguyên. Floor layer đổi từ image sang precomposition để hỗ trợ màu mép.
- Scan Now chuyển ra thanh điều khiển preview, chỉ hiện ở 00; fade 280ms và phát trực tiếp 01 theo contract. Không dùng file entry riêng. Chế độ single vẫn lặp theo rule cũ.
- Có đủ 8 .lottie; PNG nhúng giữ nguyên bytes. Không có UI app trong preview. Preview offline dùng các file cục bộ; nếu file:// bị chặn, dùng static HTTP server.
- Đã kiểm tra trên Skia Skottie và preview web; chưa kiểm tra trên iOS thật.


## v21 — bốn mép mờ và controller gradient · 22/10/2026

Thêm gradient trái/phải cùng màu #0C0C0C và độ lan 180 px trong hệ tọa độ sàn 786×652, tương tự hai mép trên/dưới. Vẫn dùng nguyên alpha PNG làm matte; chỉ thay hình dạng tô màu trong precomposition sàn. Chuyển động, easing, opacity layer gốc, timing, FPS, tỉ lệ, font và dữ liệu ảnh gốc được giữ nguyên.

Panel **Gradient sàn** nằm ngay dưới animation, cả trong stock embed và full-app-preview. Chỉnh màu, độ đậm chung 0–100%, độ lan riêng mỗi mép 0–50% chiều rộng/chiều cao sàn. Giá trị % tính trong sàn gốc, không phải canvas. Các slider đổi trực tiếp trên frame hiện tại, không reset clip. Cấu hình được nhớ trên trình duyệt và dùng khi chuyển clip; nút **Mặc định** xoá các chỉnh sửa đang dùng và trở về màu #0C0C0C/độ đậm 100%/độ lan 180 px.

**Tải cấu hình** xuất JSON thông số. **Tải Lottie đang chỉnh** xuất một .lottie của clip đang xem, đã bake màu/độ lan/độ đậm hiện tại vào JSON cùng các ảnh nhúng. Gói ZIP stock luôn chứa bản mặc định, không tự cập nhật theo slider. Các export animation 00 vẫn cần font Inter trên runtime native như bản gốc; font cho HTML preview nằm ở before-scan/animation-0/Inter.ttf. Chưa xác minh renderer native/font resolution trên iOS thật.

Có các slot Lottie: `floorGradientOpacity` (number 0–100), `floorGradientTopEnd`, `floorGradientBottomEnd`, `floorGradientLeftEnd`, `floorGradientRightEnd` (vector [x,y] theo sàn 786×652). Web controller cập nhật cả fallback và slot khi export. Runtime không hỗ trợ slots vẫn dùng fallback đã bake. Màu gradient được bake trong `g.k`; không phải color slot đơn. Panel dành cho preview/thiết kế, không phải UI người dùng production. Hai runtime JS mới (floor-gradient.js, fflate.min.js) và license đi kèm để export offline; không gọi CDN.

Không thay contract Scan Now 280ms hoặc thứ tự/chế độ lặp từng clip. Kiểm tra Skottie và web không thay thế kiểm tra player trên iOS thật.

## v21.1 — sửa controller không hiện thay đổi

Đưa lớp màu nền trắng xuống sau bốn nhóm gradient theo thứ tự vẽ Lottie. Trước đây lớp này che gradient: thông số và file export thay đổi nhưng preview không thể hiện đúng. Controller và file export nay cùng dùng đúng thứ tự lớp; mọi màu/opacity/độ lan được render ngay, kể cả khi pause. Không đổi motion, timing hoặc PNG alpha gốc. Cache của dữ liệu và script được đổi để nhận bản sửa.

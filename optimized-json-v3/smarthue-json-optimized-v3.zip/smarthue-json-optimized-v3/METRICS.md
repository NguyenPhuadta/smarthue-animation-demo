# Numeric optimization metrics

{'file': '01-tim-den', 'json_before': 6310542, 'json_after': 6310542, 'gzip_after': 636654, 'frames': 240, 'keyframes_before': 0, 'keyframes_after': 0, 'max_numeric_error': 0}
{'file': '02-tim-thay', 'json_before': 8528914, 'json_after': 5018935, 'gzip_after': 529677, 'frames': 276, 'keyframes_before': 1950, 'keyframes_after': 1165, 'max_numeric_error': 0.07999999999998408}
{'file': '03-dang-ket-noi', 'json_before': 245909, 'json_after': 238693, 'gzip_after': 104035, 'frames': 120, 'keyframes_before': 570, 'keyframes_after': 326, 'max_numeric_error': 0.07999999999998408}
{'file': '04-thanh-cong', 'json_before': 1012823, 'json_after': 916719, 'gzip_after': 348383, 'frames': 450, 'keyframes_before': 4481, 'keyframes_after': 2322, 'max_numeric_error': 0.0795}
{'file': '05-tim-thay-den-ket-noi', 'json_before': 4624448, 'json_after': 2672347, 'gzip_after': 320961, 'frames': 168, 'keyframes_before': 1119, 'keyframes_after': 693, 'max_numeric_error': 0.07966666666663968}
{'file': '07-no-light-found', 'json_before': 6741790, 'json_after': 4845718, 'gzip_after': 496589, 'frames': 252, 'keyframes_before': 2166, 'keyframes_after': 1469, 'max_numeric_error': 0.0799999999999983}
{'file': '08-connection-timeout', 'json_before': 374041, 'json_after': 235775, 'gzip_after': 87028, 'frames': 240, 'keyframes_before': 1406, 'keyframes_after': 428, 'max_numeric_error': 0.0799999999999983}
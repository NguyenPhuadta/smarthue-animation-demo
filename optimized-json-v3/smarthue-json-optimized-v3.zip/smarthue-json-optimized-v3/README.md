# SmartHue — JSON optimized v3 candidate

Separate experimental delivery. All original and previous optimized packages and previews are preserved. Seven minified Lottie JSON files, canvas 393×326, 60 fps, unchanged durations. File 01 retains optimized-search-v2 data; remaining files add bounded linear keyframe reduction to the three-decimal optimized v1 data. Embedded images are unchanged. This is a numerically lossy optimization, so approve visual results in the target app player before replacing production assets.

Total raw JSON: 20,238,729 bytes (19.30 MiB). Combined gzip payloads: 2,523,327 bytes (2.41 MiB), compared with 3,123,386 bytes (2.98 MiB) for the previous optimized v2 dotLottie files. Raw JSON is NOT smaller than dotLottie; compressing the optimized JSON makes the download smaller. The downloadable ZIP contains raw JSON and documentation; ZIP compression keeps the archive small. Extracted JSON uses the raw size above. Optimized JSON could also be repackaged as dotLottie with comparable compression: format alone is not the improvement.

Preview: https://nguyenphuadta.github.io/smarthue-animation-demo/optimized-json-v3/?rev=optimized-json-v3
Reference: https://nguyenphuadta.github.io/smarthue-animation-demo/optimized-search-v2/?rev=optimized-search-v2

The web preview fetches the gzip versions by default and decompresses into the exact delivered JSON. Append &compressed=0 to fetch raw JSON instead; it will download more bytes. Use HTTP gzip/Brotli for JSON delivery in the app/web backend where supported. If using a manual .json.gz payload, decompress it before passing parsed animation data to the player. Ordinary .json files here require no special decoder. Preload upcoming players, retain the outgoing final frame until the next is ready and avoid creating a player at each transition.

Validation: all seven files load with lottie-web and keep original frame counts at 60 fps. Successful sequence 1 → 2 → 5 → 3 → 4 → 1 completes without browser errors. Five sample frames per clip, 35 comparisons against optimized v2: mean absolute RGB channel difference 0.005316 on the 0–255 scale; largest frame-average difference 0.040744. Individual edge pixels can differ more. Start/end differences were negligible in these captures; sampled checks do not guarantee every intermediate frame or native renderer.

## Required integration behavior

Open the preview and watch full flow and individual clips before integrating. App frame reference: 393×852; animation slot X=0, Y=276, width=393, height=326; place animation beneath app UI. Preserve transparent soft floor/shadows. Playback speed 1; subframe interpolation enabled where supported. Do not cap the renderer at 30 fps.

Files/durations: 01 searching 240 frames / 4s; 02 found 276 / 4.6s; 03 connecting 120 / 2s; 04 success 450 / 7.5s; 05 found→connecting 168 / 2.8s; 07 no-light-found 252 / 4.2s; 08 timeout 240 / 4s. 06 is retired.

Successful route: 1 → 2 → 5 → 3 → 4. Error routes: 1 → 7; 3 → 8. Always finish the entire current animation before starting the next. Use autoplay=false, loop=false, completion callbacks and a pending application target. If no target is pending, repeat the whole waiting/error clip. Do not exit at a marker or use wall-clock timers. Play bridge 05 once; enter success directly from connecting. Timeout includes a 0.2s entry hold: do not add another delay. Application events determine scan completion, timeout and retry behavior; preview cycles the full success route for demonstration only. Ignore stale callbacks and dispose unused listeners.
